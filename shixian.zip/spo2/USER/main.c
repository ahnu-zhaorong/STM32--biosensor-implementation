#include "led.h"
#include "delay.h"

#include "sys.h"
#include "usart.h"
#include "iic.h"
//#include "max301002.h"
#include "max30102_2.h"
#include "algorithm.h"
#include "rc522.h"
#include "key.h"
#include "esp8266.h"
#include "lcd.h"
#include "vartypes.h"
#include "uart2.h"
/*********************************************************************************************
//��ע���Ų���///�Դ�Ϊ��׼
MAX30102:
SCL   PB6
SDA   PB7
INT   PB2
 
WIFI:
TX    PA10
RX    PA9

KEY:(�������)(S16��Ч)
C4    PB5
R4    PB4

RC522:
SDA   PB12
SCK		PB13
MOSI 	PB15
MISO	PB14
RST 	PB1

LCD:
����	PB0
CS		PD3
RS 		PD6
WR		PD4
RD		PD7
DATA  PE0~PE15
����LCD��SPI���õ��� PB12~PB15
***********************************************************************************/
//#include "stm32f10x_it.h"
extern unsigned char flag;
extern unsigned char SN[4];
extern Int16U POINT_COLOR;
//SCL     PB6
//SDA			PB7
//INT 		PE2
char str1[10][16];

#define MAX_BRIGHTNESS 255
#define INT      PBin(2)
#define led      PCout(8)  

uint32_t aun_ir_buffer[500]; //infrared LED sensor data
uint32_t aun_red_buffer[500];  //red LED sensor data
int32_t n_ir_buffer_length; //data length
int32_t n_spo2;  //SPO2 value
int8_t ch_spo2_valid;  //indicator to show if the SPO2 calculation is valid
int32_t n_heart_rate; //heart rate valu	e
int8_t  ch_hr_valid;  //indicator to show if the heart rate calculation is valid
uint8_t uch_dummy;

int32_t hr_buf[16];
int32_t hrSum;
int32_t hrAvg;
int32_t spo2_buf[16];
int32_t spo2Sum;
int32_t spo2Avg;
int32_t spo2BuffFilled;
int32_t hrBuffFilled;
int32_t hrValidCnt = 0;
int32_t spo2ValidCnt = 0;
int32_t hrThrowOutSamp = 0;
int32_t spo2ThrowOutSamp = 0;
int32_t spo2Timeout = 0;
int32_t hrTimeout = 0;
/*******************ESP8266******************/
char  AT_RST[] = {0x41, 0x54, 0x2B, 0x52, 0x53, 0x54, 0x0D, 0x0A}; 
char  AT_CWMODE[] = {0x41, 0x54, 0x2B, 0x43, 0x57, 0x4D, 0x4F, 0x44, 0x45, 0x3D,0x31, 0x0D, 0x0a};
char  AT_CWJAP[]="AT+CWJAP=\"ysln\",\"13579plm\"\r\n";
char  AT_CIPSTART[]="AT+CIPSTART=\"TCP\",\"59.110.140.133\",8888\r\n";
char  AT_CIPSEND1[]="AT+CIPSEND=51\r\n";		
char  AT_CIPSEND2[]="AT+CIPSEND=3\r\n";		
char Data[]={'2',',','I','D',':','0','0','0','0','0','0','0','0',',','H','R','=','0','1','1',',','H','R','v','a','l','i','d','=','0',',','S','P','O','2','=','0','0','0',',','S','P','O','2','V','a','l','i','d','=','0','#'};
char Data1[]={'E','N','D'};
/*************************END****************/
void loop(void);	

 int main(void)
 {	
	  
	u8 temp_num=0;
	int i;
	int key_flag;
	char str2[10][16];
	int sendtime=0;
	int tto=0;
	int over=0;
	char stri0[16],stri1[16],stri2[16],stri3[16],stri4[16],stri5[16],stri6[16],stri7[16],stri8[16],stri9[16];
	NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 //���ڳ�ʼ��Ϊ115200 
	UART2Init();
	delay_init();	    	 //��ʱ������ʼ��	
 	LED_Init();			     //LED�˿ڳ�
	KEY_Init();					//KEY_Init
	IIC_Init();        //ģ��iic��ʼ��
	delay_ms(1000);
	LCD_Init();        //LCD
	led=0;
	maxim_max30102_reset();
	maxim_max30102_read_reg(0, &uch_dummy);
	maxim_max30102_init();  //initialize the MAX30102
	delay_ms(1000);
	led=1;
	RC522_Init();	 
	LCD_Clear(WHITE);
//	ESP8266_Init(AT_RST,AT_RST,AT_CWMODE,AT_CWJAP,AT_CIPSTART);
 	while(1)
	{
		RC522_Handel();
		if(flag==0)
		{
			if(i%500==0)
			{
				//printf("�ȴ�������֤��......\n");
				LCD_ShowString(0,40,300,24,24,"Waiting for id card");
			}
				i++;
				i=i%500;
		}
		else
   	{		
			LCD_Clear(WHITE);
			//printf("���ڲɼ�����,���Ժ�......\n");
			LCD_ShowString(0,40,200,24,24,"Please prepare");
			delay_ms(1500);
			LCD_Clear(WHITE);
			//printf("�ɼ���......\n");
			LCD_ShowString(0,40,200,24,24,"Collectting data");
			delay_ms(500);
			//LCD_Clear(WHITE);
			loop();
			key_flag=0;
			for(sendtime=0;sendtime<10;sendtime++)
			{
				switch(sendtime)
				{
					case 0 : 
						for(tto=0;tto<16;tto++)
							{
								stri0[tto]=str1[sendtime][tto];
							}
							//LCD_ShowString(0,(over+1)*25,200,18,18,(unsigned char *)stri0);
							break;
					case 1 : 
						for(tto=0;tto<16;tto++)
							{
								stri1[tto]=str1[sendtime][tto];
							}
							break;					
					case 2 : 
						for(tto=0;tto<16;tto++)
							{
								stri2[tto]=str1[sendtime][tto];
							}
							break;					
					case 3 : 
						for(tto=0;tto<16;tto++)
							{
								stri3[tto]=str1[sendtime][tto];
							}
							break;					
					case 4 : 
						for(tto=0;tto<16;tto++)
							{
								stri4[tto]=str1[sendtime][tto];
							}
							break;						
					case 5 : 
						for(tto=0;tto<16;tto++)
							{
								stri5[tto]=str1[sendtime][tto];
							}
							break;					
					case 6: 
						for(tto=0;tto<16;tto++)
							{
								stri6[tto]=str1[sendtime][tto];
							}
							break;					
					case 7 : 
						for(tto=0;tto<16;tto++)
							{
								stri7[tto]=str1[sendtime][tto];
							}
							break;					
					case 8 : 
						for(tto=0;tto<16;tto++)
							{
								stri8[tto]=str1[sendtime][tto];
							}
							break;					
					case 9 : 
						for(tto=0;tto<16;tto++)
							{
								stri9[tto]=str1[sendtime][tto];
							}
							break;
				}
			}
			//printf("���ݲɼ���ϣ��밴������\n");
			LCD_ShowString(0,230,200,24,24,"PRESS THE KEY");
			while((KEY_Scan()));
			LCD_ShowString(0,230,200,24,24,"             ");
			LCD_ShowString(0,230,200,24,24,"SENDING DATA...");
			LED2=!LED2;
			printf("���Ժ�......\r\n");
			//LCD_Clear(WHITE);
			for(over=0;over<10;over++)
				{
					delay_ms(1000);
				  switch(over)
					{
						case 0 : Send_spo2(AT_CIPSEND1,Data,stri0); UART2PutString(Data); break;
						case 1 : Send_spo2(AT_CIPSEND1,Data,stri1); UART2PutString(Data); break;
						case 2 : Send_spo2(AT_CIPSEND1,Data,stri2); UART2PutString(Data); break;
						case 3 : Send_spo2(AT_CIPSEND1,Data,stri3); UART2PutString(Data); break;
						case 4 : Send_spo2(AT_CIPSEND1,Data,stri4); UART2PutString(Data); break;
						case 5 : Send_spo2(AT_CIPSEND1,Data,stri5); UART2PutString(Data); break;
						case 6 : Send_spo2(AT_CIPSEND1,Data,stri6); UART2PutString(Data); break;
						case 7 : Send_spo2(AT_CIPSEND1,Data,stri7); UART2PutString(Data); break;
						case 8 : Send_spo2(AT_CIPSEND1,Data,stri8); UART2PutString(Data); break;
						case 9 : Send_spo2(AT_CIPSEND1,Data,stri9); UART2PutString(Data); break;
					}
				}
			LCD_ShowString(0,230,200,24,24,"               ");
			LCD_ShowString(0,230,200,24,24,"SENDING IS OK");
			i=0;
			delay_ms(1500);
			LCD_Clear(WHITE);
			flag=0;
		}
			
	}	 
 }

void loop()
{
		int time=10;
	  uint32_t un_min, un_max, un_prev_data, n_brightness;  //variables to calculate the on-board LED brightness that reflects the heartbeats
    int32_t i;
    float f_temp;
		unsigned char a;
    n_brightness = 0;
    un_min = 0x3FFFF;
    un_max = 0;
	  n_ir_buffer_length = 500; //buffer length of 500 stores 5 seconds of samples running at 50sps
		


	//read the first 150 samples, and determine the signal range
    for(i = 0; i < n_ir_buffer_length; i++)
    {
        while(INT == 1); //wait until the interrupt pin asserts
			
        maxim_max30102_read_fifo((aun_red_buffer + i), (aun_ir_buffer + i)); //read from MAX30102 FIFO

        if(un_min > aun_red_buffer[i])
            un_min = aun_red_buffer[i]; //update signal min
        if(un_max < aun_red_buffer[i])
            un_max = aun_red_buffer[i]; //update signal max
				
//				printf("red=");
//        printf("%d\t", aun_red_buffer[i]);
//        printf(", ir=");
//        printf("%d\n\r", aun_ir_buffer[i]);
    }
    un_prev_data = aun_red_buffer[i];
    //calculate heart rate and SpO2 after first 150 samples (first 3 seconds of samples)
    maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_spo2, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid);

    //Continuously taking samples from MAX30102.  Heart rate and SpO2 are calculated every 1 second
    while(time)
    {
        i = 0;
        //dumping the first 50 sets of samples in the memory and shift the last 100 sets of samples to the top
        for(i = 100; i < 500; i++)
        {
            aun_red_buffer[i - 100] = aun_red_buffer[i];
            aun_ir_buffer[i - 100] = aun_ir_buffer[i];

            //update the signal min and max
            if(un_min > aun_red_buffer[i])
                un_min = aun_red_buffer[i];
            if(un_max < aun_red_buffer[i])
                un_max = aun_red_buffer[i];
        }

        //take 50 sets of samples before calculating the heart rate.
        for(i = 400; i < 500; i++)
        {
            un_prev_data = aun_red_buffer[i - 1];
						while(INT == 1);
            maxim_max30102_read_fifo((aun_red_buffer + i), (aun_ir_buffer + i));
				}

        maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_spo2, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid);

        if ((ch_hr_valid == 1) && (n_heart_rate < 190) && (n_heart_rate > 40))
        {
            hrTimeout = 0;

            // Throw out up to 1 out of every 5 valid samples if wacky
            if (hrValidCnt == 4)
            {
                hrThrowOutSamp = 1;
                hrValidCnt = 0;
                for (i = 12; i < 16; i++)
                {
                    if (n_heart_rate < hr_buf[i] + 10)
                    {
                        hrThrowOutSamp = 0;
                        hrValidCnt   = 4;
                    }
                }
            }
            else
            {
                hrValidCnt = hrValidCnt + 1;
            }

            if (hrThrowOutSamp == 0)
            {

                // Shift New Sample into buffer
                for(i = 0; i < 15; i++)
                {
                    hr_buf[i] = hr_buf[i + 1];
                }
                hr_buf[15] = n_heart_rate;

                // Update buffer fill value
                if (hrBuffFilled < 16)
                {
                    hrBuffFilled = hrBuffFilled + 1;
                }

                // Take moving average
                hrSum = 0;
                if (hrBuffFilled < 2)
                {
                    hrAvg = 0;
                }
                else if (hrBuffFilled < 4)
                {
                    for(i = 14; i < 16; i++)
                    {
                        hrSum = hrSum + hr_buf[i];
                    }
                    hrAvg = hrSum >> 1;
                }
                else if (hrBuffFilled < 8)
                {
                    for(i = 12; i < 16; i++)
                    {
                        hrSum = hrSum + hr_buf[i];
                    }
                    hrAvg = hrSum >> 2;
                }
                else if (hrBuffFilled < 16)
                {
                    for(i = 8; i < 16; i++)
                    {
                        hrSum = hrSum + hr_buf[i];
                    }
                    hrAvg = hrSum >> 3;
                }
                else
                {
                    for(i = 0; i < 16; i++)
                    {
                        hrSum = hrSum + hr_buf[i];
                    }
                    hrAvg = hrSum >> 4;
                }
            }
            hrThrowOutSamp = 0;
        }
        else
        {
            hrValidCnt = 0;
            if (hrTimeout == 4)
            {
                hrAvg = 0;
                hrBuffFilled = 0;
            }
            else
            {
                hrTimeout++;
            }
        }
				if(hrAvg<40)
				{
					ch_hr_valid=0;
				}
//						printf("HR=%d\t ", hrAvg); 
//						printf("HRvalid=%d\t ", ch_hr_valid);
//						printf("SpO2=%d\t ", n_spo2);
//						printf("SPO2Valid=%d\n\r", ch_spo2_valid);
						LCD_ShowString(0,0,200,24,24,"ID:");
						LCD_ShowString(0,(10-time)*20+30,200,24,16,"HR=   HRVal=");
						LCD_ShowString(110,(10-time)*20+30,200,24,16,"Sp=    SpVal=");
				//data 1
						str1[10-time][0]=hrAvg/100+'0';
						a=str1[10-time][0];
						LCD_ShowChar(23,(10-time)*20+30,a,16,0);
				//data 2
	          str1[10-time][1]=(hrAvg/10)%10+'0';
						a=str1[10-time][1];
						LCD_ShowChar(30,(10-time)*20+30,a,16,0);
				//data 3
	          str1[10-time][2]=hrAvg%10+'0';
						a=str1[10-time][2];
						LCD_ShowChar(37,(10-time)*20+30,a,16,0);
				//data 4
						str1[10-time][3]=ch_hr_valid+'0';
						a=str1[10-time][3];
						LCD_ShowChar(95,(10-time)*20+30,a,16,0);
				//data  5
						str1[10-time][4]=n_spo2/100+'0';
						a=str1[10-time][4];
						LCD_ShowChar(135,(10-time)*20+30,a,16,0);
				//data 6
	          str1[10-time][5]=(n_spo2/10)%10+'0';
						a=str1[10-time][5];
						LCD_ShowChar(142,(10-time)*20+30,a,16,0);
				//data 7
						str1[10-time][6]=n_spo2%10+'0';
						a=str1[10-time][6];
						LCD_ShowChar(149,(10-time)*20+30,a,16,0);
				//data 8
						str1[10-time][7]=ch_spo2_valid+'0';
						a=str1[10-time][7];
						LCD_ShowChar(210,(10-time)*20+30,a,16,0);
				//data 9		
						str1[10-time][8]=(int)SN[0]/10+'0';
						a=str1[10-time][8];
						LCD_ShowChar(40,0,a,24,0);
				//data 10
	          str1[10-time][9]=(int)SN[0]%10+'0';
						a=str1[10-time][9];
						LCD_ShowChar(58,0,a,24,0);
				//data 11
	          str1[10-time][10]=(int)SN[1]/10+'0';
						a=str1[10-time][10];
						LCD_ShowChar(76,0,a,24,0);
				//data 12
						str1[10-time][11]=(int)SN[1]%10+'0';
						a=str1[10-time][11];
						LCD_ShowChar(94,0,a,24,0);
				//data 13
						str1[10-time][12]=(int)SN[2]/10+'0';
						a=str1[10-time][12];
						LCD_ShowChar(112,0,a,24,0);
				//data 14
	          str1[10-time][13]=(int)SN[2]%10+'0';
						a=str1[10-time][13];
						LCD_ShowChar(130,0,a,24,0);
				//data 15
						str1[10-time][14]=(int)SN[3]/10+'0';
						a=str1[10-time][14];
						LCD_ShowChar(148,0,a,24,0);
				//data 16
						str1[10-time][15]=(int)SN[3]%10+'0';
						a=str1[10-time][15];
						LCD_ShowChar(166,0,a,24,0);
						//sentdata(str1);
						time=time-1;
	}
}


