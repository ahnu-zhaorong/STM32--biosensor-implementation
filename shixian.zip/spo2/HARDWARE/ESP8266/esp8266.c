#include "delay.h"
#include "esp8266.h"
#include "uart2.h"

void ESP8266_Init(char *str1,char *str2,char *str3,char *str4,char *str5)	
{
    while(*str1!='\0'){  
        USART1->DR = *str1;
			  *str1++;
       while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str2!='\0'){  
        USART1->DR = *str2;
			  *str2++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str3!='\0'){  
        USART1->DR = *str3;
			  *str3++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 8s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str4!='\0'){  
        USART1->DR = *str4;
			  *str4++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 8s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		while(*str5!='\0'){  
        USART1->DR = *str5;
			  *str5++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
}  



void Send_spo2(char *AT_CIPSEND1,char *Data,char *str1)
{
	Data[17]=str1[0];Data[18]=str1[1];Data[19]=str1[2];
	Data[29]=str1[3];  //HR
	delay_ms(500); 
	Data[36]=str1[4];Data[37]=str1[5];Data[38]=str1[6];
	Data[50]=str1[7];  //SPO2
	delay_ms(500); 
	Data[5]=str1[8];Data[6]=str1[9];Data[7]=str1[10];Data[8]=str1[11];  //ID
	Data[9]=str1[12];Data[10]=str1[13];Data[11]=str1[14];Data[12]=str1[15];
	delay_ms(500); 
	
//	while(*AT_CIPSEND1 != '\0'){   //�����ݳ���
//        USART1->DR = *AT_CIPSEND1;
//        while((USART1->SR & 0x40) == 0);
//				*AT_CIPSEND1++;
//				delay_ms(5);
//    }  
//	
//	while(*Data != '\0'){  //������
//        USART1->DR = *Data;
//        while((USART1->SR & 0x40) == 0);
//				*Data++;
//				delay_ms(5);
//    }  
	UART2PutString(Data);
}


