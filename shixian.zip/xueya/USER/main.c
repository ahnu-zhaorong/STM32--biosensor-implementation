/*********************************Copyright (c)*********************************
** Created By:             ZhaoDapeng    ���ո�Ѷ��Ϣ�Ƽ����޹�˾  
** Created date:           2015.06.02 
** Version:                2015-06-02
** Descriptions: ʹ��STM32F107VCT6     �ⲿ����25M
**   ����͸��ʵ���õ��Ĺܽ�PA9(TX1)  PA10(RX1)ע������ϵ���TTL��ƽ
**   ����1:9600  N  8  1	
** ʵ������: 			
**   LED1������˸,����1��ӡ��:����������,�Իس�������
**   ��������ַ�,�Ὣ�յ����ַ��ͻ�
*******************************************************************************/
#include "sys.h"
#include "led.h"
#include "delay.h"
#include "usart.h"
#include "uart2.h"
#include "rc522.h"
#include "key.h"
#include "lcd.h"
#include "esp8266.h"
//???????ID???
//extern u8 Flag,i;
//extern unsigned char str1[3];
extern int Flags;
extern unsigned char SN[4];
extern unsigned char flag;
extern Int16U POINT_COLOR;
extern volatile unsigned char data[5];
/*******************ESP8266******************/
char  AT_RST[] = {0x41, 0x54, 0x2B, 0x52, 0x53, 0x54, 0x0D, 0x0A}; 
char  AT_CWMODE[] = {0x41, 0x54, 0x2B, 0x43, 0x57, 0x4D, 0x4F, 0x44, 0x45, 0x3D,0x31, 0x0D, 0x0a};
char  AT_CWJAP[]="AT+CWJAP=\"ysln\",\"13579plm\"\r\n";
char  AT_CIPSTART[]="AT+CIPSTART=\"TCP\",\"59.110.140.133\",8888\r\n";
char AT_CIPSEND1[]={'A','T','+','C','I','P','S','E','N','D','=','3','1','\r','\n'};
char Data[]={'4',',','I','D',':','0','0','0','0','0','0','0','0',',','B','P','S','S','=','0','1','1',',','B','P','S','Z','=','0','1','1','#'};
char AT_CIPSEND2[]={'A','T','+','C','I','P','S','E','N','D','=','0','3','\r','\n'};
//char Data1[]={'E','N','D'};
/*************************END****************/

//void sentdata1(void)
//{
//	int i=0;  
//	for(i = 0; i < 15; i++){   //�����ݳ���
//        USART1->DR = AT_CIPSEND1[i];
//        while((USART1->SR & 0x40) == 0);
//    }  
//			delay_ms(700);
//	for(i = 0; i < 3; i++){  //������
//        USART1->DR = Data1[i];
//        while((USART1->SR & 0x40) == 0);
//    }  
//delay_ms(700);
//}
int main(void)
{		
	int i;
	int iu;
	char stri0[17];
	char a;
	unsigned char d0=0x00,d1=0x00,d2=0x00;
	//Stm32_Clock_Init(9);	//ϵͳʱ������
	delay_init();
  uart_init(9600); // 9600 
	UART2Init();
	//UART3Init(115200);
	LED_Init();
	KEY_Init();					//KEY_Init
	LCD_Init();        //LCD
  //ESP8266_Init(AT_RST,AT_RST,AT_CWMODE,AT_CWJAP,AT_CIPSTART);
	RC522_Init();	 
  LCD_Clear(WHITE);
	while(1) 
	{
		LED1=0;
		RC522_Handel();
		if(flag==0)
		{
			if(i%500==0)
			{
				//printf("�ȴ�������֤��......\n");
				LCD_ShowString(0,40,300,24,24,"Waiting for id card");
			}
				i++;
				i=i%500;
		}
		else
   	{		
			LCD_Clear(WHITE);
			//printf("���ڲɼ�����,���Ժ�......\n");
			LCD_ShowString(0,40,200,24,24,"Please prepare");
			delay_ms(1500);
			//LCD_Clear(WHITE);
		//	printf("�ɼ���......\n");
			LCD_ShowString(0,40,200,24,24,"Collectting data");
			delay_ms(600);
      	
			while(data[2]==0x00 || data[3]==0x00 || data[4]==0x00);//data not 00
      while(!(d0!=data[2] || d1!=data[3] || d2!=data[4]));//data equal			
					LCD_Clear(WHITE);
					d0=data[2];
					d1=data[3];
					d2=data[4];
					stri0[0]=data[2]/100+'0';
					stri0[1]=(data[2]/10)%10+'0';
					stri0[2]=data[2]%10+'0';
					stri0[3]=data[3]/100+'0';
					stri0[4]=(data[3]/10)%10+'0';
					stri0[5]=data[3]%10+'0';
					stri0[6]=data[4]/100+'0';
					stri0[7]=(data[4]/10)%10+'0';
					stri0[8]=data[4]%10+'0';	
					LED3=!LED3;
					LCD_ShowString(0,0,200,24,24,"ID:");
					stri0[9]=(int)SN[0]/10+'0';
					a=stri0[9];
					LCD_ShowChar(40,0,a,24,0);
					
					stri0[10]=(int)SN[0]%10+'0';
					a=stri0[10];
					LCD_ShowChar(58,0,a,24,0);
					
					stri0[11]=(int)SN[1]/10+'0';
					a=stri0[11];
					LCD_ShowChar(76,0,a,24,0);
					
					stri0[12]=(int)SN[1]%10+'0';
					a=stri0[12];
					LCD_ShowChar(94,0,a,24,0);
					
					stri0[13]=(int)SN[2]/10+'0';
					a=stri0[13];
					LCD_ShowChar(112,0,a,24,0);
					
					stri0[14]=(int)SN[2]%10+'0';
					a=stri0[14];
					LCD_ShowChar(130,0,a,24,0);
					
					stri0[15]=(int)SN[3]/10+'0';
					a=stri0[15];
					LCD_ShowChar(148,0,a,24,0);
					
					stri0[16]=(int)SN[3]%10+'0';
					a=stri0[16];
					LCD_ShowChar(166,0,a,24,0);
					
					a=stri0[0];				
					LCD_ShowChar(40,30,a,16,0);
					
					a=stri0[1];				
					LCD_ShowChar(50,30,a,16,0);
					a=stri0[2];				
					LCD_ShowChar(60,30,a,16,0);
					a=stri0[3];				
					LCD_ShowChar(80,30,a,16,0);
					a=stri0[4];				
					LCD_ShowChar(90,30,a,16,0);
					a=stri0[5];				
					LCD_ShowChar(100,30,a,16,0);
					a=stri0[6];				
					LCD_ShowChar(120,30,a,16,0);
					a=stri0[7];				
					LCD_ShowChar(130,30,a,16,0);
					a=stri0[8];				
					LCD_ShowChar(140,30,a,16,0);
	  LCD_ShowString(0,230,200,24,24,"PRESS THE KEY");
		 while((KEY_Scan()));
	  LCD_ShowString(0,230,200,24,24,"             ");
		LCD_ShowString(0,230,200,24,24,"SENDING DATA...");
		LED2=!LED2;
	  //printf("���Ժ�......\r\n");
	  Send_bps(AT_CIPSEND1,Data,stri0);
		UART2PutString(Data);
		delay_ms(7000);
		i=0;
		LCD_Clear(WHITE);
		flag=0;
//		for(iu=0;iu<4;iu++)
//				{
//					data[iu]=0x00;
//				}
		}
	}
}

