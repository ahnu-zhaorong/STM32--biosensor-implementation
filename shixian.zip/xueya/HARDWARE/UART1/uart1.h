//Filename:uart2.h
#include "sys.h"

#ifndef  _UART1_H
#define  _UART1_H

void UART3Init(u32);
void UART3PutChar(unsigned char);
void UART3PutString(unsigned char *);
unsigned char UART3GetChar(void);

#endif


