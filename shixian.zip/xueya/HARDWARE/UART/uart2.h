//Filename:uart2.h


#ifndef  _UART2_H
#define  _UART2_H

void UART2Init(void);
void UART2PutChar(unsigned char);
void UART2PutString(unsigned char *);
unsigned char UART2GetChar(void);
int Trans(unsigned char *);
extern volatile unsigned char data[5];
extern char str[9];
extern unsigned char str1[6];
extern unsigned char data1[6];
//void sentdata(char *);
#endif
