//Filename: uart2.c

#include "uart2.h"
#include "led.h"
#include "usart.h"
#include "delay.h"
#include "esp8266.h"
int i=0;
int sectimes=0;
int Flag1=0,Flags=0;
int count,counts;
//unsigned char j;
unsigned char str1[6];
char str[9];
volatile unsigned char data[5];
unsigned char data1[6];
unsigned char rev;
int times=0;
void UART2Init(void)
{
	RCC->APB2ENR |= (1uL<<2); //PA EN,PA2-U2_TX,PA3-U2_RX
	RCC->APB1ENR |= (1uL<<17);//USART2 EN

	GPIOA->CRL &=~(((7uL<<4) | (1uL<<2))<<8);  //PA2-U2_TX,PA3-U2_RX
	GPIOA->CRL |= ((1uL<<7) | (1uL<<3) | (3uL<<0))<<8;
  
	RCC->APB1RSTR |= (1uL<<17);
	RCC->APB1RSTR &= ~(1uL<<17);  //U2 Work
	
	USART2->BRR = (19uL<<4) | (8uL<<0); //115200bps
	USART2->CR1 &= ~(1uL<<12); //M=0,8 bits
	USART2->CR2 &= ~(3uL<<12); //1 Stop-bit
	USART2->CR1 = (1uL<<13) | (1uL<<5) | (1uL<<3) | (1uL<<2);
	
	NVIC_EnableIRQ(USART2_IRQn);
}

void UART2PutChar(unsigned char ch)
{
	while((USART2->SR & (1uL<<6))==0);
	USART2->DR = ch;
}

void UART2PutString(unsigned char *str)
{
	while((*str)!='\0')
		UART2PutChar(*str++);
}

unsigned char UART2GetChar(void)
{
	return USART2->DR;
}

void USART2_IRQHandler()  
{ 
	char Da;
	if(USART_GetITStatus(USART2,USART_IT_RXNE) != RESET) 
	{  
		Da=USART_ReceiveData(USART2);
		if(Da == 0xFF)
		{
			data[0] = 0;
			data[1] = 0;
			data[2] = 0;
			data[3] = 0;
			data[4] = 0;
			times=1;
		}
		if(times == 1)
		{
		  	 data[i]=Da;
			   i++;
				if(i==5)
				 times=0;
				 i=i%5;
		}
	}
	
	USART_ClearITPendingBit(USART2, USART_IT_RXNE); 
}
