
#include "sys.h"
#include "stm32f10x.h"

////
#define DS18B20_IO_IN() �{GPIOC->CRH&=0XFFFF0FFF;GPIOC->CRH|=8<<12;}
#define DS18B20_IO_OUT() {GPIOC->CRH&=0XFFFF0FFF;GPIOC->CRH|=3<<12;}
#define DS18B20_DQ_OUT PCout(11) 
#define DS18B20_DQ_IN  PCin(11) 

u8 DS18B20_Init(void);//???DS18B20
//short DS18B20_Get_Temp(void);//????
void DS18B20_Start(void);//??????
void DS18B20_Write_Bit(u8 dat);//????
void DS18B20_Write_Byte(u8 dat);//??????
u8 DS18B20_Read_Byte(void);//??????
u8 DS18B20_Read_Bit(void);//?????
u8 DS18B20_Read_2Bit(void);//??2??
u8 DS18B20_Check(void);//??????DS18B20
void DS18B20_Rst(void);//??DS18B20�
float DS18B20_Get_Temp(); //?????
int DS18B20_Search_Rom(u8 Num);//????ROM
