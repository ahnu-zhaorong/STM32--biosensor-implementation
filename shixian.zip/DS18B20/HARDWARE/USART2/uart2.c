//Filename: uart2.c

//#include "includes.h"
#include "uart2.h"
#include "led.h"
#include "delay.h"
unsigned char rev;

void UART2Init(void)
{
	RCC->APB2ENR |= (1uL<<2); //PA EN,PA2-U2_TX,PA3-U2_RX
	RCC->APB1ENR |= (1uL<<17);//USART2 EN

	GPIOA->CRL &=~(((7uL<<4) | (1uL<<2))<<8);  //PA2-U2_TX,PA3-U2_RX
	GPIOA->CRL |= ((1uL<<7) | (1uL<<3) | (3uL<<0))<<8;
  
	RCC->APB1RSTR |= (1uL<<17);
	RCC->APB1RSTR &= ~(1uL<<17);  //U2 Work
	
	USART2->BRR = (234uL<<4) | (6uL<<0); //115200bps
	USART2->CR1 &= ~(1uL<<12); //M=0,8 bits
	USART2->CR2 &= ~(3uL<<12); //1 Stop-bit
	USART2->CR1 = (1uL<<13) | (1uL<<5) | (1uL<<3) | (1uL<<2);
	
	NVIC_EnableIRQ(USART2_IRQn);
}

void UART2PutChar(char  ch)
{
	while((USART2->SR & (1uL<<6))==0);
	USART2->DR = ch;
}

void UART2PutString(char *str)
{
	while((*str)!='\0')
		UART2PutChar(*str++);
}

unsigned char UART2GetChar(void)
{
	return USART2->DR;
}

void USART2_IRQHandler(void)
{
	rev=UART2GetChar();
	UART2PutChar(rev);
	NVIC_ClearPendingIRQ(USART2_IRQn);
}
