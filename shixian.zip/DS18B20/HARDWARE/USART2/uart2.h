//Filename:uart2.h


#include "sys.h"

#ifndef  _UART2_H
#define  _UART2_H

void UART2Init(void);
void UART2PutChar(char);
void UART2PutString(char *);
unsigned char UART2GetChar(void);

#endif

