//Filename: lcd.c
//��ʹ��9341���������ͺ���䱻ע�ͻ�ɾȥ

#include "includes.h"
#include "textlib.h"

//д���ݺ���  ����Ϊ�꣬�ӿ촦������
#define LCD_WR_DATA(data){\
LCD_RS_SET;\
LCD_CS_CLR;\
DATAOUT(data);\
LCD_WR_CLR;\
LCD_WR_SET;\
LCD_CS_SET;\
}

typedef struct  
{										    
	Int16U  width;
	Int16U  height;
	Int16U  id;
	Int08U  dir;       //0:Portrait, 1:Landscape
	Int16U	wramcmd;   //Write GRAM
	Int16U  setxcmd;	 //Set X-Coor
	Int16U  setycmd;	 //Set Y-Coor
}LcdDev;
LcdDev  dev;

Int16U POINT_COLOR = 0x0000;	    //����Ĭ��ɫ
Int16U BACK_COLOR  = 0xFFFF;      //����Ĭ��ɫ

void LCDDelay(Int32U t)   //t-us
{
	Int32U i;
	Int08U j;
	for(i=0;i<t;i++)
	{
		for(j=0;j<12;j++);
	}
}

//д�Ĵ�������
void LCD_WR_REG(Int16U data)
{ 
	LCD_RS_CLR;
 	LCD_CS_CLR; 
	DATAOUT(data); 
	LCD_WR_CLR; 
	LCD_WR_SET; 
 	LCD_CS_SET;   
}

//д���ݺ���  ��һ��д��������
void LCD_WR_DATAX(Int16U data)
{
	LCD_RS_SET;
	LCD_CS_CLR;
	DATAOUT(data);
	LCD_WR_CLR;
	LCD_WR_SET;
	LCD_CS_SET;
}

//������
Int16U LCD_RD_DATA(void)
{										   
	Int16U t;
 	GPIOE->CRL = 0X88888888; //PE0-7  ��������
	GPIOE->CRH = 0X88888888; //PE8-15 ��������
	GPIOE->ODR = 0X0000; 

	LCD_RS_SET;
	LCD_CS_CLR;
	LCD_RD_CLR;
	if(dev.id == 0X8989) LCDDelay(2);   //For 8989, delay 2us.					   
	t = DATAIN;  
	LCD_RD_SET;
	LCD_CS_SET; 

	GPIOE->CRL = 0X33333333; //PE0-7  �������
	GPIOE->CRH = 0X33333333; //PE8-15 �������
	GPIOE->ODR = 0XFFFF;
	return t;  
}

//д�Ĵ���
void LCD_WriteReg(Int16U LCD_Reg,Int16U LCD_RegValue)
{	
	LCD_WR_REG(LCD_Reg);   //�Ĵ������ 
	LCD_WR_DATA(LCD_RegValue);	    		 
}   
//���Ĵ���
Int16U LCD_ReadReg(Int16U LCD_Reg)
{										   
 	LCD_WR_REG(LCD_Reg);   //�Ĵ������
	return LCD_RD_DATA(); 
} 

//׼��дGRAM
void LCD_WriteRAM_Prepare(void)
{
	LCD_WR_REG(dev.wramcmd);
} 
//дGRAM
void LCD_WriteRAM(Int16U RGB_Code)
{							    
	LCD_WR_DATA(RGB_Code);
}

//��ɫֵ��ʽת�������Է��ϲ�ͬ����Ҫ��
Int16U LCD_BGR2RGB(Int16U c)
{
	Int16U  r,g,b,rgb;   
	b=(c>>0)&0x1f;
	g=(c>>5)&0x3f;
	r=(c>>11)&0x1f;	 
	rgb=(b<<11)+(g<<5)+(r<<0);		 
	return(rgb);
}		 

//��ȡĳ����ɫֵ
Int16U LCD_ReadPoint(Int16U x,Int16U y)
{
 	Int16U r,g,b;
	if(x>=dev.width||y>=dev.height)return 0;
	LCD_SetCursor(x,y);
	if(dev.id==0X9341||dev.id==0X6804||dev.id==0X5310)LCD_WR_REG(0X2E);	//9341/6804/5310
//	else if(dev.id==0X5510)LCD_WR_REG(0X2E00);	//5510
//	else LCD_WR_REG(R34);    //other
	GPIOE->CRL=0X88888888;  //PE0-7  ��������
	GPIOE->CRH=0X88888888;  //PE8-15 ��������
	GPIOE->ODR=0XFFFF; 

	LCD_RS_SET;
	LCD_CS_CLR;	    
	LCD_RD_CLR;	
  LCDDelay(1);
	LCD_RD_SET;
	LCD_RD_CLR;					   
	LCDDelay(1);
 	r=DATAIN;
	LCD_RD_SET;
 	if(dev.id==0X9341||dev.id==0X5310||dev.id==0X5510)	                //9341/NT35310/NT35510
	{	 
		LCD_RD_CLR;					   
		b=DATAIN;
	 	LCD_RD_SET;
		g=r&0XFF;
		g<<=8;
	}

	LCD_CS_SET;
	GPIOE->CRL=0X33333333; 		//PE0-7  �������
	GPIOE->CRH=0X33333333; 		//PE8-15 �������
	GPIOE->ODR=0XFFFF;
	
//	if(dev.id==0X9325||dev.id==0X4535||dev.id==0X4531||dev.id==0X8989||dev.id==0XB505)return r;
//	else if(dev.id==0X9341||dev.id==0X5310||dev.id==0X5510)return (((r>>11)<<11)|((g>>10)<<5)|(b>>11));//ILI9341/NT35310/NT35510
//	else return LCD_BGR2RGB(r);	//other
  if(dev.id == 0X9341) return (((r>>11)<<11)|((g>>10)<<5)|(b>>11));
	else return 0;
}

//������ʾ
void LCD_DisplayOn(void)
{	
	if(dev.id==0X9341||dev.id==0X6804||dev.id==0X5310)LCD_WR_REG(0X29);	
//	else if(dev.id==0X5510)LCD_WR_REG(0X2900);
//	else LCD_WriteReg(R7,0x0173);
}	 
//�ر���ʾ
void LCD_DisplayOff(void)
{	   
	if(dev.id==0X9341||dev.id==0X6804||dev.id==0X5310)LCD_WR_REG(0X28);
//	else if(dev.id==0X5510)LCD_WR_REG(0X2800);
//	else LCD_WriteReg(R7, 0x0);
}   

//���ù��λ��
void LCD_SetCursor(Int16U Xpos, Int16U Ypos)
{
 	if(dev.id==0X9341||dev.id==0X5310)
	{		    
		LCD_WR_REG(dev.setxcmd); 
		LCD_WR_DATA(Xpos>>8); 
		LCD_WR_DATA(Xpos&0XFF);	 
		LCD_WR_REG(dev.setycmd); 
		LCD_WR_DATA(Ypos>>8); 
		LCD_WR_DATA(Ypos&0XFF);
	} else {
		if(dev.dir==1)Xpos=dev.width-1-Xpos;
		LCD_WriteReg(dev.setxcmd, Xpos);
		LCD_WriteReg(dev.setycmd, Ypos);
	}
}

//����LCD�Զ�ɨ�跽��  dir:0~7����8������ ��lcd.h
void LCD_Scan_Dir(Int08U dir)
{
	Int16U regval=0;
	Int16U dirreg=0;
	Int16U temp;  
	if(dev.dir==1&&dev.id!=0X6804)
	{			   
		switch(dir)
		{
			case 0:dir=6;break;
			case 1:dir=7;break;
			case 2:dir=4;break;
			case 3:dir=5;break;
			case 4:dir=1;break;
			case 5:dir=0;break;
			case 6:dir=3;break;
			case 7:dir=2;break;	     
		}
	}
	
	if(dev.id==0x9341||dev.id==0X6804||dev.id==0X5310||dev.id==0X5510)
	{
		switch(dir)
		{
			case L2R_U2D:
				regval|=(0<<7)|(0<<6)|(0<<5); 
				break;
			case L2R_D2U:
				regval|=(1<<7)|(0<<6)|(0<<5); 
				break;
			case R2L_U2D:
				regval|=(0<<7)|(1<<6)|(0<<5); 
				break;
			case R2L_D2U:
				regval|=(1<<7)|(1<<6)|(0<<5); 
				break;	 
			case U2D_L2R:
				regval|=(0<<7)|(0<<6)|(1<<5); 
				break;
			case U2D_R2L:
				regval|=(0<<7)|(1<<6)|(1<<5); 
				break;
			case D2U_L2R:
				regval|=(1<<7)|(0<<6)|(1<<5); 
				break;
			case D2U_R2L:
				regval|=(1<<7)|(1<<6)|(1<<5); 
				break;	 
		}
    dirreg=0X36;
		LCD_WriteReg(dirreg,regval);
 		
		if((regval&0X20)||dev.dir==1)
		{
			if(dev.width<dev.height)
			{
				temp=dev.width;
				dev.width=dev.height;
				dev.height=temp;
 			}
		} else {
			if(dev.width>dev.height)
			{
				temp=dev.width;
				dev.width=dev.height;
				dev.height=temp;
 			}
		}  

		LCD_WR_REG(dev.setxcmd); 
		LCD_WR_DATA(0);LCD_WR_DATA(0);
		LCD_WR_DATA((dev.width-1)>>8);LCD_WR_DATA((dev.width-1)&0XFF);
		LCD_WR_REG(dev.setycmd); 
		LCD_WR_DATA(0);LCD_WR_DATA(0);
		LCD_WR_DATA((dev.height-1)>>8);LCD_WR_DATA((dev.height-1)&0XFF);  
  }
	
}

//���
void LCD_DrawPoint(Int16U x,Int16U y)
{
	LCD_SetCursor(x,y);
	LCD_WriteRAM_Prepare();
	LCD_WR_DATA(POINT_COLOR); //�û���ɫ��ȫ���������
}  	 

//��һ����㺯�����Ͽ���
void LCD_Fast_DrawPoint(Int16U x,Int16U y,Int16U color)
{	   
	if(dev.id==0X9341||dev.id==0X5310)
	{
		LCD_WR_REG(dev.setxcmd); 
		LCD_WR_DATA(x>>8); 
		LCD_WR_DATA(x&0XFF);	 
		LCD_WR_REG(dev.setycmd); 
		LCD_WR_DATA(y>>8); 
		LCD_WR_DATA(y&0XFF);
	} else {
 		return;
	}
	LCD_RS_CLR;
 	LCD_CS_CLR; 
	DATAOUT(dev.wramcmd);   //дָ��
	LCD_WR_CLR; 
	LCD_WR_SET; 
 	LCD_CS_SET; 
	LCD_WR_DATA(color);		  //д����
}

//������Ļ����  0 ���� 1����
void LCD_Display_Dir(Int08U dir)
{
	if(dir==0)
	{
		dev.dir = 0;
		dev.width = 240;
		dev.height = 320;
		if(dev.id==0X9341||dev.id==0X6804||dev.id==0X5310)
		{
			dev.wramcmd = 0X2C;
	 		dev.setxcmd = 0X2A;
			dev.setycmd = 0X2B;
		} else {
			return;
		}
	} 
	else 	//����
	{	  				
		dev.dir = 1;
		dev.width = 320;
		dev.height = 240;
		if(dev.id==0X9341||dev.id==0X5310)
		{
			dev.wramcmd = 0X2C;
	 		dev.setxcmd = 0X2A;
			dev.setycmd = 0X2B;
		} else {
			return;
		}
	}
	LCD_Scan_Dir(DFT_SCAN_DIR);	 //Ĭ��ɨ�跽��ɨ��һ��
}	 


//LCD��ʼ��  ����Ӧ9341 
void LCD_Init(void)
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE|RCC_APB2Periph_AFIO, ENABLE); //B�ڡ�D�ڡ�E�ڼ�AFIOʹ��
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	   //PB0Ϊ����������� ��LCD_LED
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 			
	GPIO_SetBits(GPIOB,GPIO_Pin_0);              //��������
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;//PD3~PD7���ܼ�lcd.h   ����PD5��LCD_RST�͵�ƽ��Ч
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 	
	GPIO_SetBits(GPIOD,GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
	GPIO_Init(GPIOE, &GPIO_InitStructure); 
	GPIO_SetBits(GPIOE,GPIO_Pin_All);

	LCDDelay(50*1000);           // delay 50 ms 
	LCD_WriteReg(0x0000,0x0001);
	LCDDelay(50*1000);           // delay 50 ms 
  
	dev.id = LCD_ReadReg(0x0000);   
	if(dev.id<0XFF || dev.id==0XFFFF || dev.id==0X9300)
	{
		LCD_WR_REG(0XD3);				   
		LCD_RD_DATA();
 		LCD_RD_DATA();
    dev.id = LCD_RD_DATA();
 		dev.id <<= 8;
		dev.id |= LCD_RD_DATA();     //*******9341*******
	}
 	
	//printf(" LCD ID:%x\r\n",dev.id);
	if(dev.id==0X9341)             //*******9341*******
	{	 
		LCD_WR_REG(0xCF);  
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0xC1); 
		LCD_WR_DATAX(0X30); 
		LCD_WR_REG(0xED);  
		LCD_WR_DATAX(0x64); 
		LCD_WR_DATAX(0x03); 
		LCD_WR_DATAX(0X12); 
		LCD_WR_DATAX(0X81); 
		LCD_WR_REG(0xE8);  
		LCD_WR_DATAX(0x85); 
		LCD_WR_DATAX(0x10); 
		LCD_WR_DATAX(0x7A); 
		LCD_WR_REG(0xCB);  
		LCD_WR_DATAX(0x39); 
		LCD_WR_DATAX(0x2C); 
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x34); 
		LCD_WR_DATAX(0x02); 
		LCD_WR_REG(0xF7);  
		LCD_WR_DATAX(0x20); 
		LCD_WR_REG(0xEA);  
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x00); 
		LCD_WR_REG(0xC0);    //Power control 
		LCD_WR_DATAX(0x1B);   //VRH[5:0] 
		LCD_WR_REG(0xC1);    //Power control 
		LCD_WR_DATAX(0x01);   //SAP[2:0];BT[3:0] 
		LCD_WR_REG(0xC5);    //VCM control 
		LCD_WR_DATAX(0x30); 	 //3F
		LCD_WR_DATAX(0x30); 	 //3C
		LCD_WR_REG(0xC7);    //VCM control2 
		LCD_WR_DATAX(0XB7); 
		LCD_WR_REG(0x36);    // Memory Access Control 
		LCD_WR_DATAX(0x48); 
		LCD_WR_REG(0x3A);   
		LCD_WR_DATAX(0x55); 
		LCD_WR_REG(0xB1);   
		LCD_WR_DATAX(0x00);   
		LCD_WR_DATAX(0x1A); 
		LCD_WR_REG(0xB6);    // Display Function Control 
		LCD_WR_DATAX(0x0A); 
		LCD_WR_DATAX(0xA2); 
		LCD_WR_REG(0xF2);    // 3Gamma Function Disable 
		LCD_WR_DATAX(0x00); 
		LCD_WR_REG(0x26);    //Gamma curve selected 
		LCD_WR_DATAX(0x01); 
		LCD_WR_REG(0xE0);    //Set Gamma 
		LCD_WR_DATAX(0x0F); 
		LCD_WR_DATAX(0x2A); 
		LCD_WR_DATAX(0x28); 
		LCD_WR_DATAX(0x08); 
		LCD_WR_DATAX(0x0E); 
		LCD_WR_DATAX(0x08); 
		LCD_WR_DATAX(0x54); 
		LCD_WR_DATAX(0XA9); 
		LCD_WR_DATAX(0x43); 
		LCD_WR_DATAX(0x0A); 
		LCD_WR_DATAX(0x0F); 
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x00); 		 
		LCD_WR_REG(0XE1);    //Set Gamma 
		LCD_WR_DATAX(0x00); 
		LCD_WR_DATAX(0x15); 
		LCD_WR_DATAX(0x17); 
		LCD_WR_DATAX(0x07); 
		LCD_WR_DATAX(0x11); 
		LCD_WR_DATAX(0x06); 
		LCD_WR_DATAX(0x2B); 
		LCD_WR_DATAX(0x56); 
		LCD_WR_DATAX(0x3C); 
		LCD_WR_DATAX(0x05); 
		LCD_WR_DATAX(0x10); 
		LCD_WR_DATAX(0x0F); 
		LCD_WR_DATAX(0x3F); 
		LCD_WR_DATAX(0x3F); 
		LCD_WR_DATAX(0x0F); 
		LCD_WR_REG(0x2B); 
		LCD_WR_DATAX(0x00);
		LCD_WR_DATAX(0x00);
		LCD_WR_DATAX(0x01);
		LCD_WR_DATAX(0x3f);
		LCD_WR_REG(0x2A); 
		LCD_WR_DATAX(0x00);
		LCD_WR_DATAX(0x00);
		LCD_WR_DATAX(0x00);
		LCD_WR_DATAX(0xef);	 
		LCD_WR_REG(0x11);     //Exit Sleep
		LCDDelay(120*1000);
		LCD_WR_REG(0x29);     //display on	
	} else {      // ��ȡҺ����IDʧ��  ֱ�ӷ���
	  return;
	}

	LCD_Display_Dir(0);	
	LCD_Clear(WHITE);
}
  

//���������Ϊָ����ɫ
void LCD_Clear(Int16U color)
{
	u32 index=0;      
	u32 totalpoint=dev.width;
	totalpoint*=dev.height; 			//���ص�����
	LCD_SetCursor(0x00,0x0000);
	LCD_WriteRAM_Prepare();
	for(index=0;index<totalpoint;index++)LCD_WR_DATA(color);	
}  


//ָ��λ����ʾ�����ַ�
//size: 12/16/24
//mode: 1/0 Ĭ��0
void LCD_ShowChar(Int16U x,Int16U y,Int08U num,Int08U size,Int08U mode)
{  							  
  Int08U temp,t1,t;
	Int16U y0=y;
	Int08U csize=(size/8+((size%8)?1:0))*(size/2);		//����size�ȵ��ַ�������ռ�ֽ���

	num=num-' ';    //����ƫ��
	for(t=0;t<csize;t++)
	{   
		if(size==12)temp=asc2_1206[num][t]; 	 	  //1206�������
		else if(size==16)temp=asc2_1608[num][t];	//1608
		else if(size==24)temp=asc2_2412[num][t];	//2412
		else return;      //�����ڵ�size
		for(t1=0;t1<8;t1++)
		{			    
			if(temp&0x80)LCD_Fast_DrawPoint(x,y,POINT_COLOR);
			else if(mode==0)LCD_Fast_DrawPoint(x,y,BACK_COLOR);   //�ǵ��ӷ�ʽ
			temp<<=1;
			y++;
			if(x>=dev.width)return;		     //�Ƿ���λ��
			if((y-y0)==size)
			{
				y=y0;
				x++;
				if(x>=dev.width)return;
				break;
			}
		}
	}
}

//ָ��λ����ʾ�ַ���
void LCD_ShowString(Int16U x,Int16U y,Int16U width,Int16U height,Int08U size,Int08U *p)
{         
	Int08U x0 = x;
	width += x;
	height += y;
    while((*p <= '~')&&(*p >= ' '))     //�Ƿ�Ƿ��ַ�
    {
        if(x >= width) {x = x0; y += size;}
        if(y >= height) break;          //�Ƿ���λ��
        LCD_ShowChar(x,y,*p,size,0);
        x += size/2;
        p++;
    }
}

//����16X16������
void DrawHZ16X16(Int16U x,Int16U y,Int08U *hz,Int08U len)
{
	Int08U i,j,k;
	Int16U code;
	Int08U *addr;
	Int08U ch;
	for(k=0;k<len;k++)
	{
		code=hz[2*k]<<8 | hz[2*k+1];
		switch(code)
		{
			case 0xCEC2: //��
				addr=&HZ16X16[0];
				break;
			case 0xCAAA: //ʪ
				addr=&HZ16X16[32];
				break;
			case 0xB6C8: //��
				addr=&HZ16X16[2*32];
				break;
			case 0xC9E3: //��  Temperature Signal
				addr=&HZ16X16[3*32];
			  break;
			default:
				break;
		}
		for(i=0;i<16;i++)
		{
			ch=*(addr+2*i);
			for(j=0;j<8;j++) //1st Byte
			{
				if((ch & (1u<<(7-j)))==(1u<<(7-j)))
					LCD_Fast_DrawPoint(x+j+16*k,y+i,POINT_COLOR); 
				else
					LCD_Fast_DrawPoint(x+j+16*k,y+i,BACK_COLOR); 
			}
			ch=*(addr+2*i+1);
			for(j=0;j<8;j++) //2nd Byte
			{
				if((ch & (1u<<(7-j)))==(1u<<(7-j)))
					LCD_Fast_DrawPoint(x+j+8+16*k,y+i,POINT_COLOR); 
				else
					LCD_Fast_DrawPoint(x+j+8+16*k,y+i,BACK_COLOR); 
			}
		}
	}
}

