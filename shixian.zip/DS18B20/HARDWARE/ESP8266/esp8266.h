#ifndef __ESP8266_H
#define __ESP8266_H
#include "sys.h"


void ESP8266_Init(char *str1,char *str2,char *str3,char *str4,char *str5);	
void Send_temp(char *AT_CIPSEND1,char *Data,char *str1);
#endif
