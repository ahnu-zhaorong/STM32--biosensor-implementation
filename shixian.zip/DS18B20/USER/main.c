/*********************************Copyright (c)*********************************
** Created By:             ZhaoDapeng    ���ո�Ѷ��Ϣ�Ƽ����޹�˾  
** Created date:           2015.06.02 
** Version:                2015-06-02
** Descriptions: ʹ��STM32F107VCT6     �ⲿ����25M
**   ����͸��ʵ���õ��Ĺܽ�PA9(TX1)  PA10(RX1)ע������ϵ���TTL��ƽ
**   ����1:9600  N  8  1	
** ʵ������: 			
**   LED1������˸,����1��ӡ��:����������,�Իس�������
**   ��������ַ�,�Ὣ�յ����ַ��ͻ�
*******************************************************************************/
#include "sys.h"
#include "led.h"
#include "delay.h"
#include "usart.h"
#include "ds18b20.h"
#include "rc522.h"
#include "key.h"
#include "esp8266.h"
#include "lcd.h"
#include "vartypes.h"
#include "uart2.h"
//???????ID???
extern unsigned char DS18B20_ID[8][8];
extern unsigned char DS18B20_SensorNum;
extern unsigned char flag;
extern unsigned char SN[4];
extern Int16U POINT_COLOR;

char str1[10][11];
/*******************ESP8266******************/
/*******************ESP8266******************/
char  AT_RST[] = "AT+RST\r\n";
char  AT_CWMODE[] = {0x41, 0x54, 0x2B, 0x43, 0x57, 0x4D, 0x4F, 0x44, 0x45, 0x3D,0x31, 0x0D, 0x0a};
char  AT_CWJAP[]="AT+CWJAP=\"ysln\",\"13579plm\"\r\n";
char  AT_CIPSTART[]="AT+CIPSTART=\"TCP\",\"59.110.140.133\",8888\r\n";
char  AT_CIPSEND1[]="AT+CIPSEND=25\r\n";		
char  AT_CIPSEND2[]="AT+CIPSEND=3\r\n";
char Data[]={'1',',','I','D',':','0','0','0','0','0','0','0','0',',','T','E','M','P','=','0','0','0','.','0','0','#'};
//char tempData[]={'{','"','t','y','p','e','"',':','"','t','e','m','p','"',',','"','v','a','l','u','e','"',':','"','2','5','"','}','\r','\n'};
//char Data1[3]={'E','N','D'};
	/*************************END****************/

int main(void)
{		
	u8 num=0,i; 
	float temp1=0;
	int temp=0;
	int sendtime=0;
	int tto=0;
	int over=0;
	char stri0[12],stri1[12],stri2[12],stri3[12],stri4[12],stri5[12],stri6[12],stri7[12],stri8[12],stri9[12];
  delay_init();
  uart_init(115200); // 9600 
	UART2Init();
	LED_Init();
	KEY_Init();					//KEY_Init
	LCD_Init();        //LCD
	LED1=1;
	LED2=0;
  ESP8266_Init(AT_RST,AT_RST,AT_CWMODE,AT_CWJAP,AT_CIPSTART);
	RC522_Init();	 

  while(DS18B20_Init())//???DS18B20,18B20 �
  {
		LCD_ShowString(0,0,300,24,24,"DS18B20 Check Failed!");
	}
	LCD_Clear(WHITE);
	while(1) 
	{  
		RC522_Handel();
		if(flag==0)
		{
			if(i%500==0)
			{
				//printf("�ȴ�������֤��......\n");
				LCD_ShowString(0,40,300,24,24,"Waiting for id card");
			}
				i++;
				i=i%500;
		}
		else
   	{		
			int time=10;
			LCD_Clear(WHITE);
			//printf("���ڲɼ�����,���Ժ�......\n");
			LCD_ShowString(0,40,200,24,24,"Please prepare");
			delay_ms(3000);
			//LCD_Clear(WHITE);
			//printf("�ɼ���......\n");
			LCD_ShowString(0,40,200,24,24,"Collectting data");
			delay_ms(3000);
			LCD_Clear(WHITE);
		while(time)
		{
						char a;
						int i;
						LCD_ShowString(0,0,200,24,24,"ID:");
						
						for(i=0;i<10;i++)
						{
							temp1=DS18B20_Get_Temp();
							delay_ms(100);
						}
						LCD_ShowString(0,(10-time)*20+30,200,24,16,"TEMP:");
						LCD_ShowChar(60,(10-time)*20+30,'.',16,0);
					  temp=temp1*100;
						//printf("TM:%.2f\r\n",temp1);
//TEMP			//DATA 1
						str1[10-time][0]=temp/1000+'0';
						a=str1[10-time][0];
						LCD_ShowChar(40,(10-time)*20+30,a,16,0);
			//DATA 2 
						str1[10-time][1]=(temp%1000)/100+'0';
						a=str1[10-time][1];
						LCD_ShowChar(50,(10-time)*20+30,a,16,0);
			//DATA 3
						str1[10-time][10]=(temp%100)/10+'0';
						a=str1[10-time][10];
						LCD_ShowChar(70,(10-time)*20+30,a,16,0);
			//DATA 3
						str1[10-time][11]=temp%10+'0';
					  a=str1[10-time][11];
						LCD_ShowChar(80,(10-time)*20+30,a,16,0);
//CARD			//DATA3
						LCD_ShowString(0,0,200,24,24,"ID:");
						str1[10-time][2]=(int)SN[0]/10+'0';
						a=str1[10-time][2];
						LCD_ShowChar(40,0,a,24,0);
				//data 10
	          str1[10-time][3]=(int)SN[0]%10+'0';
						a=str1[10-time][3];
						LCD_ShowChar(58,0,a,24,0);
				//data 11
	          str1[10-time][4]=(int)SN[1]/10+'0';
						a=str1[10-time][4];
						LCD_ShowChar(76,0,a,24,0);
				//data 12
						str1[10-time][5]=(int)SN[1]%10+'0';
						a=str1[10-time][5];
						LCD_ShowChar(94,0,a,24,0);
				//data 13
						str1[10-time][6]=(int)SN[2]/10+'0';
						a=str1[10-time][6];
						LCD_ShowChar(112,0,a,24,0);
				//data 14
	          str1[10-time][7]=(int)SN[2]%10+'0';
						a=str1[10-time][7];
						LCD_ShowChar(130,0,a,24,0);
				//data 15
						str1[10-time][8]=(int)SN[3]/10+'0';
						a=str1[10-time][8];
						LCD_ShowChar(148,0,a,24,0);
				//data 10
						str1[10-time][9]=(int)SN[3]%10+'0';
						a=str1[10-time][9];
						LCD_ShowChar(166,0,a,24,0);
						time=time-1;
						delay_ms(300);
		}
		for(sendtime=0;sendtime<10;sendtime++)
			{
				switch(sendtime)
				{
					case 0 : 
						for(tto=0;tto<12;tto++)
							{
								stri0[tto]=str1[sendtime][tto];
							}
							//LCD_ShowString(0,(over+1)*25,200,18,18,(unsigned char *)stri0);
							break;
					case 1 : 
						for(tto=0;tto<12;tto++)
							{
								stri1[tto]=str1[sendtime][tto];
							}
							break;					
					case 2 : 
						for(tto=0;tto<12;tto++)
							{
								stri2[tto]=str1[sendtime][tto];
							}
							break;					
					case 3 : 
						for(tto=0;tto<12;tto++)
							{
								stri3[tto]=str1[sendtime][tto];
							}
							break;					
					case 4 : 
						for(tto=0;tto<12;tto++)
							{
								stri4[tto]=str1[sendtime][tto];
							}
							break;						
					case 5 : 
						for(tto=0;tto<12;tto++)
							{
								stri5[tto]=str1[sendtime][tto];
							}
							break;					
					case 6: 
						for(tto=0;tto<12;tto++)
							{
								stri6[tto]=str1[sendtime][tto];
							}
							break;					
					case 7 : 
						for(tto=0;tto<12;tto++)
							{
								stri7[tto]=str1[sendtime][tto];
							}
							break;					
					case 8 : 
						for(tto=0;tto<12;tto++)
							{
								stri8[tto]=str1[sendtime][tto];
							}
							break;					
					case 9 : 
						for(tto=0;tto<12;tto++)
							{
								stri9[tto]=str1[sendtime][tto];
							}
							break;
				}
			}
		//printf("���ݲɼ���ϣ��밴������\n");
			//LCD_Clear(WHITE);
			//printf("���ڲɼ�����,���Ժ�......\n");
	  LCD_ShowString(0,230,200,24,24,"PRESS THE KEY");
		while((KEY_Scan()));
	  LCD_ShowString(0,230,200,24,24,"             ");
		LCD_ShowString(0,230,200,24,24,"SENDING DATA...");
		LED2=!LED2;
	 // printf("���Ժ�......\r\n");
		for(over=0;over<10;over++)
				{
					delay_ms(1000);
				  switch(over)
					{
						case 0 : Send_temp(AT_CIPSEND1,Data,stri0); UART2PutString(Data); break;
						case 1 : Send_temp(AT_CIPSEND1,Data,stri1); UART2PutString(Data); break;
						case 2 : Send_temp(AT_CIPSEND1,Data,stri2); UART2PutString(Data); break;
						case 3 : Send_temp(AT_CIPSEND1,Data,stri3); UART2PutString(Data); break;
						case 4 : Send_temp(AT_CIPSEND1,Data,stri4); UART2PutString(Data); break;
						case 5 : Send_temp(AT_CIPSEND1,Data,stri5); UART2PutString(Data); break;
						case 6 : Send_temp(AT_CIPSEND1,Data,stri6); UART2PutString(Data); break;
						case 7 : Send_temp(AT_CIPSEND1,Data,stri7); UART2PutString(Data); break;
						case 8 : Send_temp(AT_CIPSEND1,Data,stri8); UART2PutString(Data); break;
						case 9 : Send_temp(AT_CIPSEND1,Data,stri9); UART2PutString(Data); break;
					}
				}
		//sentdata1();
		LCD_ShowString(0,230,200,24,24,"               ");
		LCD_ShowString(0,230,200,24,24,"SENDING IS OK");
		i=0;
		delay_ms(1700);
		LCD_Clear(WHITE);
		flag=0;
		}
	} 
}

