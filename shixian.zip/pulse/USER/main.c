#include "sys.h"
#include "usart.h"		
#include "delay.h"	
#include "led.h" 
#include "key.h"	 	
#include "adc.h"	
#include "timer.h"	
#include "rc522.h"
#include "key.h"
#include "esp8266.h"
#include "lcd.h"
#include "uart2.h"

#define SAMPLE_PERIOD	20  	// ���β�������(ms)
#define BUFF_SIZE	  65		// ���ݻ�������С

extern unsigned char flag;
extern unsigned char SN[4];
extern Int16U POINT_COLOR;
char sendbuf[8];
char sendbuf2[5][6];
char sendbuf1[1000][10];
int c=0;

typedef enum {FALSE, TRUE} BOOL;

uint16_t readData, preReadData;		   		// ��ȡ���� AD ֵ
uint16_t timeCount = 0;         // �������ڼ�������
uint16_t firstTimeCount = 0;    // ��һ������ʱ��
uint16_t secondTimeCount = 0;   // �ڶ�������ʱ��

/* ���͸���λ���������� IBI: ��������������ʱ�䣬BPM: ����ֵ�� SIG: ����ͼ����ֵ����ʾ*/
uint16_t IBI, BPM, SIG;   		


uint16_t data[BUFF_SIZE] = {0}; // �������ݻ���
uint8_t index = 0; 				// ���������±�
uint16_t max, min, mid;			// �����С���м�ֵ
uint16_t filter=0;				// �˲�ֵ


BOOL PULSE = FALSE;				// ��Ч����
BOOL PRE_PULSE = FALSE;         // ��ǰ��Ч����


uint8_t pulseCount = 0;			// ��������
uint32_t i;


uint16_t Get_Array_Max(uint16_t * array, uint32_t size);
uint16_t Get_Array_Min(uint16_t * array, uint32_t size);
void loop(void);


void  Show_ID(unsigned char *SN);
void  Show_DATA(void);
/*******************ESP8266******************/
char  AT_RST[] = {0x41, 0x54, 0x2B, 0x52, 0x53, 0x54, 0x0D, 0x0A}; 
char  AT_CWMODE[] = {0x41, 0x54, 0x2B, 0x43, 0x57, 0x4D, 0x4F, 0x44, 0x45, 0x3D,0x31, 0x0D, 0x0a};
char  AT_CWJAP[]="AT+CWJAP=\"ysln\",\"13579plm\"\r\n";
char  AT_CIPSTART[]="AT+CIPSTART=\"TCP\",\"59.110.140.133\",8888\r\n";
char  AT_CIPSEND1[]="AT+CIPSEND=32\r\n";		
char  AT_CIPSEND2[]="AT+CIPSEND=3\r\n";						 
char  Data1[]={'3',',','I','D',':','0','0','0','0','0','0','0','0',',','B','=','0','0','0',',','Q','=','0','0','0',',','S','=','0','0','0','0','#'};
//char  Data2[]={'E','N','D'};
/*************************END****************/



int main(void)
{	
	int i;
	int d=0;
	int sendtime1=0;
	char string[4];
	int sendtime=0;
	int tto=0;
	unsigned char s1;
	char stri0[14],stri1[14],stri2[14],stri3[14],stri4[14];
	//Stm32_Clock_Init(9);	//ϵͳʱ������
	uart_init(115200); 	//���ڳ�ʼ��Ϊ115200
	UART2Init();//9200
	delay_init();	   	 	//��ʱ��ʼ�� 
	LED_Init();		  		//��ʼ����LED���ӵ�Ӳ���ӿ� 
	Timer_6_Init();
	ADC_AN2_Init();
	KEY_Init();					//KEY_Init 
	ESP8266_Init(AT_RST,AT_RST,AT_CWMODE,AT_CWJAP,AT_CIPSTART);
	LCD_Init();        //LCD
	RC522_Init();	 
	LCD_Clear(WHITE);
 	while(1)
	{
		RC522_Handel();
		if(flag==0)
		{
			if(i%500==0)
			{
				LCD_ShowString(0,40,300,24,24,"Waiting for id card");
			}
				i++;
				i=i%500;
		}
		else
   	{		
			LCD_Clear(WHITE);
			LCD_ShowString(0,40,200,24,24,"Please prepare");
			delay_ms(1000);
			LCD_ShowString(0,40,200,24,24,"Collectting data");
			LCD_ShowString(0,80,300,24,16,"It needs a few minutes");
			delay_ms(1000);
			c=0;
			loop();
			LCD_Clear(WHITE);
			Show_ID(SN);
	    for(sendtime=0;sendtime<5;sendtime++)
			 {
				switch(sendtime)
				{
					case 0 : 
						LCD_ShowString(45,sendtime*15+30,200,24,16,"Q=");
					  LCD_ShowString(86,sendtime*15+30,200,24,16,"B=");
						for(tto=0;tto<6;tto++)
							{
								stri0[tto]=sendbuf2[sendtime][tto];
								if(tto<3)
								{
									s1=stri0[tto];
									LCD_ShowChar(60+tto*7,sendtime*15+30,s1,16,0);
								}
								else if(tto<6 && tto>2)
								{
									s1=stri0[tto];
									LCD_ShowChar(80+tto*7,sendtime*15+30,s1,16,0);
								}
							}
							//   LCD_ShowString(0,(over+1)*25,200,18,18,(unsigned char *)stri0);
							break;
					case 1 : 
						LCD_ShowString(45,sendtime*15+30,200,24,16,"Q=");
					  LCD_ShowString(86,sendtime*15+30,200,24,16,"B=");
						for(tto=0;tto<6;tto++)
							{
								stri1[tto]=sendbuf2[sendtime][tto];
								if(tto<3)
								{
									s1=stri1[tto];
									LCD_ShowChar(60+tto*7,sendtime*15+30,s1,16,0);
								}
								else if(tto<6 && tto>2)
								{
									s1=stri1[tto];
									LCD_ShowChar(80+tto*7,sendtime*15+30,s1,16,0);
								}
								
							}
							break;					
					case 2 : 
						LCD_ShowString(45,sendtime*15+30,200,24,16,"Q=");
					  LCD_ShowString(86,sendtime*15+30,200,24,16,"B=");
						for(tto=0;tto<6;tto++)
							{
								stri2[tto]=sendbuf2[sendtime][tto];
								if(tto<3)
								{
									s1=stri2[tto];
									LCD_ShowChar(60+tto*7,sendtime*15+30,s1,16,0);
								}
								else if(tto<6 && tto>2)
								{
									s1=stri2[tto];
									LCD_ShowChar(80+tto*7,sendtime*15+30,s1,16,0);
								}
							}
							break;					
					case 3 : 
						LCD_ShowString(45,sendtime*15+30,200,24,16,"Q=");
					  LCD_ShowString(86,sendtime*15+30,200,24,16,"B=");
						for(tto=0;tto<6;tto++)
							{
								stri3[tto]=sendbuf2[sendtime][tto];
								if(tto<3)
								{
									s1=stri3[tto];
									LCD_ShowChar(60+tto*7,sendtime*15+30,s1,16,0);
								}
								else if(tto<6 && tto>2)
								{
									s1=stri3[tto];
									LCD_ShowChar(80+tto*7,sendtime*15+30,s1,16,0);
								}
							}
							break;					
					case 4 : 
						LCD_ShowString(45,sendtime*15+30,200,24,16,"Q=");
					  LCD_ShowString(86,sendtime*15+30,200,24,16,"B=");
						for(tto=0;tto<6;tto++)
							{
								stri4[tto]=sendbuf2[sendtime][tto];
								if(tto<3)
								{
									s1=stri4[tto];
									LCD_ShowChar(60+tto*7,sendtime*15+30,s1,16,0);
								}
								else if(tto<6 && tto>2)
								{
									s1=stri4[tto];
									LCD_ShowChar(80+tto*7,sendtime*15+30,s1,16,0);
								}
							}
							break;						
				}
			}
			LCD_ShowString(0,230,200,24,24,"PRESS THE KEY");
			while((KEY_Scan()));
			LCD_ShowString(0,230,200,24,24,"             ");
			LCD_ShowString(0,230,200,24,24,"SENDING DATA...");
			LED2=!LED2;
			for(sendtime1=0;sendtime1<c;sendtime1++)
			{
				for(d=0;d<10;d++)
					{
						string[d]=sendbuf1[sendtime1][d];
					}
						Send_pulse(AT_CIPSEND1,Data1,string,sendbuf);
					  UART2PutString(Data1);
			}
			LCD_ShowString(0,230,200,24,24,"               ");
			LCD_ShowString(0,230,200,24,24,"SENDING IS OK");
			delay_ms(1000);
			delay_ms(1000);
			LCD_Clear(WHITE);
			i=0;
			flag=0;
		}
	}
}

void loop(void)
{
		int time=32;
	  int count=0;
		while(time)
		{
				//%dprintf("IT IS \r\n");  // ���ڴ�ӡ����
				preReadData = readData;	        // ����ǰһ��ֵ
				readData = Get_ADC_1_CH2();		// ��ȡADת��ֵ
				
				if ((readData - preReadData) <= filter)    // �˳�ͻ�������źŸ���
					data[index++] = readData;	// ��仺������

				if (index >= BUFF_SIZE)
				{	
					index = 0;	// ������������ͷ����
					// ͨ�����������ȡ�����źŵĲ��塢����ֵ���������м�ֵ��Ϊ�ж��ο���ֵ
					max = Get_Array_Max(data, BUFF_SIZE);
					min = Get_Array_Min(data, BUFF_SIZE);
					mid = (max + min)/2;
					filter = (max - min) / 2;
				}
				
				PRE_PULSE = PULSE;	// ���浱ǰ����״̬
				PULSE = (readData > mid) ? TRUE : FALSE;  // ����ֵ�����м�ֵΪ��Ч����
				
				if (PRE_PULSE == FALSE && PULSE == TRUE)  // Ѱ�ҵ����ź�����������м�λ�á��������㣬��⵽һ����Ч����
				{	
					pulseCount++;
					pulseCount %= 2;	 
					
					if(pulseCount == 1) // ���������ĵ�һ��
					{                         	
						firstTimeCount = timeCount;   // ��¼��һ������ʱ��
					}
					if(pulseCount == 0)  // ���������ĵڶ���
					{                             			
						secondTimeCount = timeCount;  // ��¼�ڶ�������ʱ��
						timeCount = 0;	

						if ( (secondTimeCount > firstTimeCount))
						{
							IBI = (secondTimeCount - firstTimeCount) * SAMPLE_PERIOD;	// ������������������ʱ�䣬�õ� IBI
							BPM = 60000 / IBI;  // ͨ�� IBI �õ�����ֵ BPM
							
						}
					
					}
								time=time-1;
								if(time<=5)
								{
                sendbuf2[5-time][0]=(int)((IBI)%1000)/100+'0';
								sendbuf2[5-time][1]=(int)((IBI)%100)/10+'0';	 
								sendbuf2[5-time][2]=(int)(IBI)%10+'0';		 
							
								sendbuf2[5-time][3]=(int)((BPM)%1000)/100+'0';		 
								sendbuf2[5-time][4]=(int)((BPM)%100)/10+'0';		 
								sendbuf2[5-time][5]=(int)(BPM)%10+'0';
								}
				}		
				if(time<5)
				{
					 sendbuf1[c][0]=(int)(readData)/1000+'0';
					 sendbuf1[c][1]=(int)((readData)%1000)/100+'0';
					 sendbuf1[c][2]=(int)((readData)%100)/10+'0';
					 sendbuf1[c][3]=(int)(readData)%10+'0';
					 
					 sendbuf1[c][4]=(int)((IBI)%1000)/100+'0';
					 sendbuf1[c][5]=(int)((IBI)%100)/10+'0';	 
					 sendbuf1[c][6]=(int)(IBI)%10+'0';		 
								
					 sendbuf1[c][7]=(int)((BPM)%1000)/100+'0';		 
					 sendbuf1[c][8]=(int)((BPM)%100)/10+'0';		 
					 sendbuf1[c][9]=(int)(BPM)%10+'0';
					 c++;
				}
				// printf("%d \r\n",readData);
				 //printf("S:%d B:%d Q:%d\r\n",readData,BPM,IBI);
				 timeCount++;  // ʱ������ۼ� 
				 Timer_6_Delay_ms(SAMPLE_PERIOD); // ��ʱ�ٽ�����һ���ڲ���
				 LED2=!LED2;//��˸LED,��ʾϵͳ��������.
	  }
}	
	
uint16_t Get_Array_Max(uint16_t * array, uint32_t size)
{
	uint16_t max = array[0];
	uint32_t i;
	
	for (i = 1; i < size; i++)
	{
		if (array[i] > max)
			max = data[i];
	}
	
	return max;
}

uint16_t Get_Array_Min(uint16_t * array, uint32_t size)
{
	uint16_t min = array[0];
	uint32_t i;
	
	for (i = 1; i < size; i++)
	{
		if (array[i] < min)
			min = data[i];
	}
	
	return min;
}


/**********************************/
void Show_ID(unsigned char *SN)
{
	
			int i;
			char id;
	    LCD_ShowString(0,0,200,24,24,"ID:");
			sendbuf[0]=(int)SN[0]/10+'0';
	    sendbuf[1]=(int)SN[0]%10+'0';
	    sendbuf[2]=(int)SN[1]/10+'0';
			sendbuf[3]=(int)SN[1]%10+'0';
			sendbuf[4]=(int)SN[2]/10+'0';
			sendbuf[5]=(int)SN[2]%10+'0';
			sendbuf[6]=(int)SN[3]/10+'0';
			sendbuf[7]=(int)SN[3]%10+'0';
			for(i=0;i<8;i++)
			{
				id=sendbuf[i];
				LCD_ShowChar(40+i*18,0,id,24,0);
			}
}



