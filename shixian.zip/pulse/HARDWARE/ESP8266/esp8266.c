#include "delay.h"
#include "esp8266.h"
#include "uart2.h"

void ESP8266_Init(char *str1,char *str2,char *str3,char *str4,char *str5)	
{
    while(*str1!='\0'){  
        USART1->DR = *str1;
			  *str1++;
       while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str2!='\0'){  
        USART1->DR = *str2;
			  *str2++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str3!='\0'){  
        USART1->DR = *str3;
			  *str3++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 8s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
    while(*str4!='\0'){  
        USART1->DR = *str4;
			  *str4++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 8s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
		while(*str5!='\0'){  
        USART1->DR = *str5;
			  *str5++;
        while((USART1->SR & 0x40) == 0);
			delay_ms(5);
    }  
		delay_ms(500);//delay 5s
		delay_ms(1500);
		delay_ms(1500);
		delay_ms(1500);
}  



void Send_pulse(char *AT_CIPSEND1,char *Data1,char *str1,char *str2)
{
	Data1[16]=str1[7];Data1[17]=str1[8];Data1[18]=str1[9]; //B
	delay_ms(50); 
	Data1[22]=str1[4];Data1[23]=str1[5];Data1[24]=str1[6]; //Q
	delay_ms(50); 
	Data1[28]=str1[0];Data1[29]=str1[1];Data1[30]=str1[2];Data1[31]=str1[3]; //S
	delay_ms(50); 
	
	Data1[5]=str2[0];Data1[6]=str2[1];Data1[7]=str2[2];Data1[8]=str2[3];  //ID
	Data1[9]=str2[4];Data1[10]=str2[5];Data1[11]=str2[6];Data1[12]=str2[7];
	delay_ms(500); 
	
//	while(*AT_CIPSEND1 != '\0'){   //�����ݳ���
//        USART1->DR = *AT_CIPSEND1;
//        while((USART1->SR & 0x40) == 0);
//				*AT_CIPSEND1++;
//				delay_ms(5);
//    }  
//	
//	while(*Data1 != '\0'){  //������
//        USART1->DR = *Data1;
//        while((USART1->SR & 0x40) == 0);
//				*Data1++;
//				delay_ms(5);
//    }  
	//UART2PutString(Data1);
}


