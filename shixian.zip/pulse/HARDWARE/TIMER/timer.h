#ifndef __TIMER6_H__
#define __TIMER6_H__
#include "sys.h" 

void Timer_6_Init(void);
void Timer_6_Delay_ms(u16 ms);
void Timer_6_Delay_us(u16 us);

#endif
