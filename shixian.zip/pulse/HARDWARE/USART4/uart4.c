//Filename: uart4.c

//#include "includes.h"
#include "uart4.h"
#include "led.h"
#include "delay.h"
unsigned char rev1;

void UART4Init(void)
{
	RCC->APB2ENR |= (1uL<<4); //PC EN,PC10-U4_TX,PC11-U4_RX
	RCC->APB1ENR |= (1uL<<19);//USART4 EN

	GPIOC->CRH &=0XFFFF00FF;//PC10-U4_TX,PC11-U4_RX
	GPIOC->CRH |=0X00008B00;
  
	RCC->APB1RSTR |= (1uL<<19);
	RCC->APB1RSTR &= ~(1uL<<19);  //U4 Work
	UART4->BRR = (234uL<<4) | (6uL<<0); //9200bps
	UART4->CR1 &= ~(1uL<<12); //M=0,8 bits
	UART4->CR2 &= ~(3uL<<12); //1 Stop-bit
	UART4->CR1 = (1uL<<13) | (1uL<<5) | (1uL<<3) | (1uL<<2);
	NVIC_EnableIRQ(UART4_IRQn);
}

void UART4PutChar(unsigned char  ch)
{
	while((UART4->SR & (1uL<<6))==0);
	UART4->DR = ch;
}

void UART4PutString(unsigned char *str)
{
	while((*str)!='\0')
		UART4PutChar(*str++);
}

unsigned char UART4GetChar(void)
{
	return UART4->DR;
}

void USART4_IRQHandler(void)
{
	rev1=UART4GetChar();
	UART4PutChar(rev1);
	NVIC_ClearPendingIRQ(UART4_IRQn);
}
