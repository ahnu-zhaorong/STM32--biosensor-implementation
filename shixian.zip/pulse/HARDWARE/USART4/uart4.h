//Filename:uart4.h
#include "sys.h"

#ifndef  _UART4_H
#define  _UART4_H

void UART4Init(void);
void UART4PutChar(unsigned char);
void UART4PutString(unsigned char *);
unsigned char UART4GetChar(void);

#endif

