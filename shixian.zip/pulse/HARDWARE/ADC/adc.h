#ifndef __ADC_H__
#define __ADC_H__
#include "sys.h" 


void ADC_AN2_Init(void);
u16 Get_ADC_1_CH2(void);

#endif
