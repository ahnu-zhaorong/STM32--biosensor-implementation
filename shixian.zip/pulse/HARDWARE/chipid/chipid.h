#ifndef __CHIPID_H
#define	__CHIPID_H


#include "stm32f10x.h"

void Get_ChipID(void);

#endif /* __CHIPID_H */
