/*********************************Copyright (c)*********************************
** Created By:             ZhaoDapeng    ���ո�Ѷ��Ϣ�Ƽ����޹�˾  
** Created date:           2015.06.03 
** Version:                2015-06-03
**    ���Ź������ļ�
*******************************************************************************/
#include "wdg.h"

void WatchdogInit(void)
{
	
	/* Check if the system has resumed from IWDG reset */
	if (RCC_GetFlagStatus(RCC_FLAG_IWDGRST) != RESET)
	{
		/* Clear reset flags */
		RCC_ClearFlag();
	}

	/* IWDG timeout equal to 280 ms (the timeout may varies due to LSI frequency
		dispersion) */
	/* Enable write access to IWDG_PR and IWDG_RLR registers */
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);

	/* IWDG counter clock: 40KHz(LSI) / 32 = 1.25 KHz ��0.8ms*/   //��Ƶ4--256
	//IWDG_SetPrescaler(IWDG_Prescaler_32);
	IWDG_SetPrescaler(IWDG_Prescaler_256);  //40KHz/256 = 156.25Hz ��0.0064s

	/* Set counter reload value to 349 */
	//IWDG_SetReload(349);   //350*0.0008=0.28s    ��ֵ��Χ0--0x0fff
	//IWDG_SetReload(1562);   //1562*0.0064=9.9968s
	IWDG_SetReload(781);   //781*0.0064=4.9984s

	/* Reload IWDG counter */
	IWDG_ReloadCounter();  //ι��

	/* Enable IWDG (the LSI oscillator will be enabled by hardware) */
	IWDG_Enable();

}


